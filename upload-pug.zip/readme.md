https://gist.github.com/stardustxx/58748550699228174b805aaadfc98a35
